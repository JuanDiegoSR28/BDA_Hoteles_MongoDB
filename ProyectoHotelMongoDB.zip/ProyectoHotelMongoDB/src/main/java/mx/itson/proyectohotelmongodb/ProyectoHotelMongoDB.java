/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package mx.itson.proyectohotelmongodb;

/**
 *
 * @author PC
 */
public class ProyectoHotelMongoDB {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
